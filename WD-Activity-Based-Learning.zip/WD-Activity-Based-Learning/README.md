# WD-Activity-Based-Learning

Web Development Activity-Based Learning assignment containing the three selected case studies, their webpage screenshots, and the consolidated screenshot report.

## Student details
- **Name:** Srinivas *(from the supplied Student Profile page; please verify spelling/details)*
- **Roll Number:** 24CSE101 *(from the supplied Student Profile page; please verify)*
- **Branch:** Computer Science Engineering *(from the supplied Student Profile page)*
- **Section:** **[Please provide section]**

## Selected case studies
1. **My Student Profile** — `case-studies/01-student-profile.html`
2. **NRI Institute of Technology — Admissions** — `case-studies/02-nriit-admissions.html`
3. **Sweet Treats Bakery** — `case-studies/03-sweet-treats-bakery.html`

## Report and screenshots
- Consolidated PDF: [`Consolidated-Report.pdf`](Consolidated-Report.pdf)
- Screenshot files: [`screenshots/`](screenshots/)

## Run locally
Open any HTML file in the `case-studies/` directory in a modern web browser. No build tools or dependencies are required.

## Notes
The original third activity file included Markdown code fences outside the HTML document. Those fences were removed in the submission copy so the browser can render the page correctly; the page content itself was preserved.
